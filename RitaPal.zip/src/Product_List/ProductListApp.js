import React, { useEffect, useState } from "react";
let i;
const ProductListApp = (props) => {
  console.log(props.productArr);
  const [checkArr,setCheckArr]=useState([]);
  let arrData = [];
  const checkarrData = () => {
  const checked=  props.productArr.filter((element) => {
     
      const dublicate = checkArr.includes(element.primary_category);
      console.log(dublicate);
      if (!dublicate) {
        arrData.push(element.primary_category);
        return true;
      } else {
        return false;
      }
    });
    console.log(checked);
  };
  useEffect(() => {
    checkarrData();
  }, []);

  return (
    <div id="outerProduct">
      <h1>Products</h1>
      <select>
        {props.productArr.map((item, i) => {
          return <option index={i}>{item.primary_category}</option>;
        })}
      </select>
    </div>
  );
};

export default ProductListApp;
